<?php
error_reporting(0);
require "init.php";
 
$username = $_POST["username"];
$password = $_POST["password"];
 
$sql = "INSERT INTO `new` (`username`, `password`) VALUES ('".$username."', '".$password."');";
if(!mysqli_query($con, $sql)){
    echo '{"message":"Unable to save the data to the database."}';
}
 
?>