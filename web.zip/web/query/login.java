class BackGround extends AsyncTask<String, String, String> {
 
        @Override
        protected String doInBackground(String... params) {
            String username = params[0];
            String password = params[1];
            String data="";
            int tmp;
 
            try {
                URL url = new URL("http://localhost/Cross/login.php");
                String urlParams = "username="+username+"&password="+password;
 
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setDoOutput(true);
                OutputStream os = httpURLConnection.getOutputStream();
                os.write(urlParams.getBytes());
                os.flush();
                os.close();
 
                InputStream is = httpURLConnection.getInputStream();
                while((tmp=is.read())!=-1){
                    data+= (char)tmp;
                }
 
                is.close();
                httpURLConnection.disconnect();
 
                return data;
            } catch (MalformedURLException e) {
                e.printStackTrace();
                return "Exception: "+e.getMessage();
            } catch (IOException e) {
                e.printStackTrace();
                return "Exception: "+e.getMessage();
            }
        }
 
        @Override
        protected void onPostExecute(String s) {
            String err=null;
            try {
                JSONObject root = new JSONObject(s);
                JSONObject user_data = root.getJSONObject("user");
                NAME = user_data.getString("fname")+" "+user_data.getString("mname")+" "+user_data.getString("lname");
                PHONE = user_data.getString("phonenum");
                EMAIL = user_data.getString("email");
                ADDRESS = user_data.getString("address");
            } catch (JSONException e) {
                e.printStackTrace();
                err = "Exception: "+e.getMessage();
            }
 
            Intent i = new Intent(ctx, ProfileActivity.class);
            i.putExtra("name", NAME);
            i.putExtra("phonenum", PHONE);
            i.putExtra("email", EMAIL);
            i.putExtra("address", ADDRESS);
            i.putExtra("err", err);
            startActivity(i);
 
        }
    }