<?php
 
error_reporting(0);
 
$server_name = "localhost";
$mysql_user = "root";
$mysql_pass = "";
$db_name = "heroplus";
 
$con = mysqli_connect($server_name, $mysql_user, $mysql_pass, $db_name);
 
if(!$con){
    echo '{"message":"Unable to connect to the database."}';
}
else{
	echo "Hooray!";
}
 
?>