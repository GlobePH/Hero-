<?php
class loginController extends CI_Controller {
	public function __construct() {
        parent::__construct();
        $this->load->model('adminModel');
    }

	public function index(){
		$this->verifyLogin();
	}

	public function verifyLogin(){
        //This method will have the credentials validation
        //$this->load->library('form_validation');
        if($this->session->userdata('logged_in')){
            $session_data = $this->session->userdata('logged_in');
            $data['admin_username'] = $session_data['admin_username'];
            $data['admin_password'] = $session_data['admin_password'];
            $data['admin_fName'] = $session_data['admin_fName'];
            $data['admin_mName'] = $session_data['admin_mName'];
            $data['admin_lName'] = $session_data['admin_lName'];
            redirect('homeController/home');
        }
            
        else{
            // If no session, redirect to login page
            $this->form_validation->set_rules('username', 'Username', 'required');
            $this->form_validation->set_rules('userpass', 'Password', 'required|callback_check_database');
 
            if($this->form_validation->run() == FALSE){
                //Field validation failed.  User redirected to login page
                $this->load->view('login.html');
            }
            else{
                //Go to private area
                ini_set('max_execution_time', 300);
                redirect('homeController/home');
            }
        }        
    }

    public function check_database($password){
        //Field validation succeeded.  Validate against database
        $username = $this->input->post('username');
 
        //query the database
        $result = $this->adminModel->checkAdmin($username, $password);
 
        if($result){
            $sess_array = array();
            foreach($result as $row){
                $sess_array = array(
                    'admin_username' => $row->admin_userName,
                    'admin_fName' => $row->admin_fName,
                    'admin_mName' => $row->admin_mName,
                    'admin_lName' => $row->admin_lName,
                    'admin_password' => $row->admin_password
                );
                $this->session->set_userdata('logged_in', $sess_array);
            }
            return TRUE;
        }
        else{
            //$this->form_validation->set_message('check_database', 'Invalid username or password');
            $this->session->set_flashdata('failed', 'Incorrect username and password. Try again.');
            return false;
        }
    }
}
