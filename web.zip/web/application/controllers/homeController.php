<?php
class homeController extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('userModel');
    }

	public function index(){
		$this->load->view('index.html');
	}

	public function home(){
		if($this->session->userdata('logged_in')){
            $session_data = $this->session->userdata('logged_in');
            $data['admin_username'] = $session_data['admin_username'];
            $data['admin_fName'] = $session_data['admin_fName'];
            $data['admin_mName'] = $session_data['admin_mName'];
            $data['admin_lName'] = $session_data['admin_lName'];
            $data['admin_password'] = $session_data['admin_password'];

            $data['hospitalLimited'] = $this->userModel->getHospitalLimited();
            $data['policeLimited'] = $this->userModel->getPoliceLimited();
            $data['fireLimited'] = $this->userModel->getFireLimited();
            $data['totalHospital'] = $this->userModel->getTotalHospital();
            $data['totalPolice'] = $this->userModel->getTotalPolice();
            $data['totalFire'] = $this->userModel->getTotalFire();

			$this->load->view('homeAdmin.html', $data);
        }
        else{
            //If no session, redirect to login page
            redirect('loginController/index');
        }
	}


    public function hospital() {
        if($this->session->userdata('logged_in')){
            $session_data = $this->session->userdata('logged_in');
            $data['admin_username'] = $session_data['admin_username'];
            $data['admin_fName'] = $session_data['admin_fName'];
            $data['admin_mName'] = $session_data['admin_mName'];
            $data['admin_lName'] = $session_data['admin_lName'];
            $data['admin_password'] = $session_data['admin_password'];

            $data['hospitalLimited'] = $this->userModel->getHospitalLimited();
            $data['policeLimited'] = $this->userModel->getPoliceLimited();
            $data['fireLimited'] = $this->userModel->getFireLimited();

            $data['users'] = $this->userModel->getUsersUnhelpHospital();

            $this->load->view('hospitalAdmin.html', $data);
        }
        else{
            //If no session, redirect to login page
            redirect('loginController/index');
        }
    }

    public function policestation(){
        if($this->session->userdata('logged_in')){
            $session_data = $this->session->userdata('logged_in');
            $data['admin_username'] = $session_data['admin_username'];
            $data['admin_fName'] = $session_data['admin_fName'];
            $data['admin_mName'] = $session_data['admin_mName'];
            $data['admin_lName'] = $session_data['admin_lName'];
            $data['admin_password'] = $session_data['admin_password'];

            $data['hospitalLimited'] = $this->userModel->getHospitalLimited();
            $data['policeLimited'] = $this->userModel->getPoliceLimited();
            $data['fireLimited'] = $this->userModel->getFireLimited();

            $data['users'] = $this->userModel->getUsersUnhelpPolice();

            $this->load->view('policestationAdmin.html', $data);
        }
        else{
            //If no session, redirect to login page
            redirect('loginController/index');
        }
    }

    public function firestation() {
        if($this->session->userdata('logged_in')){
            $session_data = $this->session->userdata('logged_in');
            $data['admin_username'] = $session_data['admin_username'];
            $data['admin_fName'] = $session_data['admin_fName'];
            $data['admin_mName'] = $session_data['admin_mName'];
            $data['admin_lName'] = $session_data['admin_lName'];
            $data['admin_password'] = $session_data['admin_password'];

            $data['hospitalLimited'] = $this->userModel->getHospitalLimited();
            $data['policeLimited'] = $this->userModel->getPoliceLimited();
            $data['fireLimited'] = $this->userModel->getFireLimited();

            $data['users'] = $this->userModel->getUsersUnhelpFire();

            $this->load->view('firestationAdmin.html', $data);
        }
        else{
            //If no session, redirect to login page
            redirect('loginController/index');
        }
    }






	public function logout(){
            session_destroy();
            redirect('loginController/index');
        }
}
