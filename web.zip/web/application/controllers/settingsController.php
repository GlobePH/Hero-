<?php
class settingsController extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('userModel');
		$this->load->library('pagination');
	}

	public function index(){
		
	}
	public function manageUser(){
		if($this->session->userdata('logged_in')){
            $session_data = $this->session->userdata('logged_in');
            $data['admin_username'] = $session_data['admin_username'];
            $data['admin_fName'] = $session_data['admin_fName'];
            $data['admin_mName'] = $session_data['admin_mName'];
            $data['admin_lName'] = $session_data['admin_lName'];
            $data['admin_password'] = $session_data['admin_password'];

            $per_page = 6;
            $start_row = $this->uri->segment(4);
            if(trim($start_row) == ""){$start_row = 0;}    
            $data['users'] = $this->userModel->getUserLimited($start_row, $per_page);  
            $data['count'] = $this->userModel->countUser();    
            $this->load->view("manageUser.html", $data);
        }
        else{
            //If no session, redirect to login page
            redirect('loginController/index');
        }
	}

    // Delete user
    public function delete($uname = ""){
        $this->db->delete('user', array('uname' => $uname));
        $this->session->set_flashdata('success', 'Success! User has been deleted.');
        redirect('settingsController/manageUser');
    }
}
