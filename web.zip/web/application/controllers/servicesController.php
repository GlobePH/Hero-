<?php
class servicesController extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('servicesMapModel');
	}

	public function index(){
		
	}
	public function hospital(){
		$this->load->view('hospital.html');
	}
	public function hospitalMap(){
		$this->load->view('hospitalMap.html');
	}
	public function hospitalMapAdmin(){
		$data['latlng'] = $this->servicesMapModel->getLatLng();

		$this->load->view('hospitalMapAdmin.html', $data);
	}
	public function police(){
		$this->load->view('police.html');
	}
	public function policeMap(){
		$this->load->view('policeMap.html');
	}
	public function policeMapAdmin(){
		$data['latlng'] = $this->servicesMapModel->getLatLng();


		$this->load->view('policeMapAdmin.html', $data);
	}
	public function fire(){
		$this->load->view('fire.html');
	}
	public function fireMap(){
		$this->load->view('fireMap.html');
	}
	public function fireMapAdmin(){
		$data['latlng'] = $this->servicesMapModel->getLatLng();

		$this->load->view('fireMapAdmin.html', $data);
	}
}
