<?php 

    class servicesMapModel extends CI_Model{
                
        function __construct() {
            parent::__construct();
        }
        public function getLatLng(){
            $query_str = "Select Latitude, Longitude from address limit 1";
            $result = $this->db->query($query_str);
            return $result->result();
        }
        public function getLat(){
            $query_str = "Select Latitude from address limit 1";
            $result = $this->db->query($query_str);
            return $result->result();
        }
        public function getLong(){
            $query_str = "Select Longitude from address limit 1";
            $result = $this->db->query($query_str);
            return $result->result();
        }



    }
?>