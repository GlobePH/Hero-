<?php 

    class userModel extends CI_Model{
                
        function __construct() {
            parent::__construct();
        }
        
        public function getData() {
            return $this->db->count_all("user");
        }


        public function getUserLimited($start_row, $limit) {
            $query_str = "Select * from user order by fname asc";
            $result = $this->db->query($query_str);
            return $result->result();
        }

        public function countUser(){
            $query_str = "Select * from user";
            $result = $this->db->query($query_str);
            return $result->num_rows();
        }

        public function getUsers(){
            $this->load->database();
            $query = $this->db->get('user');
            return $query->result();
        }




        public function getHospitalLimited(){
            $query_str = "select * from transaction, user, address where transaction.addressID = address.addressID and transaction.uname = user.uname AND service = 'Hospital' order by transactionID asc limit 5";
            $result = $this->db->query($query_str);
            return $result->result();
        }

        public function getPoliceLimited(){
            $query_str = "select * from transaction, user, address where transaction.addressID = address.addressID and transaction.uname = user.uname AND service = 'Police' order by transactionID asc limit 5";
            $result = $this->db->query($query_str);
            return $result->result();
        }

        public function getFireLimited(){
            $query_str = "select * from transaction, user, address where transaction.addressID = address.addressID and transaction.uname = user.uname AND service = 'Fire' order by transactionID asc limit 5";
            $result = $this->db->query($query_str);
            return $result->result();
        }

        public function getTotalHospital(){
            $query_str = "select * from transaction where service = 'Hospital'";
            $result = $this->db->query($query_str);
            return $result->num_rows();
        }

        public function getTotalPolice(){
            $query_str = "select * from transaction where service = 'Police'";
            $result = $this->db->query($query_str);
            return $result->num_rows();
        }

        public function getTotalFire(){
            $query_str = "select * from transaction where service = 'Fire'";
            $result = $this->db->query($query_str);
            return $result->num_rows();
        }


        public function getUsersUnhelpHospital(){
            $query_str = "select user.uname, fname, mname, lname, birthdate, gender,
            contact, email, dateCreated, dateUpdated, status from transaction, user 
            where transaction.uname = user.uname 
            AND service = 'Hospital'
            AND status is NULL";
            $result = $this->db->query($query_str);
            return $result->result();
        }

        public function getUsersUnhelpPolice(){
            $query_str = "select user.uname, fname, mname, lname, birthdate, gender,
            contact, email, dateCreated, dateUpdated, status from transaction, user 
            where transaction.uname = user.uname 
            AND service = 'Police'
            AND status is NULL";
            $result = $this->db->query($query_str);
            return $result->result();
        }

        public function getUsersUnhelpFire(){
            $query_str = "select user.uname, fname, mname, lname, birthdate, gender,
            contact, email, dateCreated, dateUpdated, status from transaction, user 
            where transaction.uname = user.uname 
            AND service = 'Fire'
            AND status is NULL";
            $result = $this->db->query($query_str);
            return $result->result();
        }
    }
    
?>