<?php 

    class adminModel extends CI_Model{
                
        function __construct() {
            parent::__construct();
        }
        
        // Admin Table
        public function checkAdmin($username, $pass){
            $this->db->from('admin');
            $this->db->where('admin_username', $username);
            $this->db->where('admin_password', $pass);
            $result = $this->db->get();
            
            if($result->num_rows() > 0 ){
                return $result->result();
            }
            else{
                return FALSE;
            }
        }
    }
    
?>